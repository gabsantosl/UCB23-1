/*
GABRIELA DOS SANTOS LEITE
LISTA DE EXERC�CIOS 14/03/2023

EXERC�CIO 04- Fa�a um programa que entra com a idade de uma pessoa e se a idade for maior que 70 anos, aparece
			  a mensagem "Velho". Se a idade for maior que 21 anos, "Adulto". Se a idade for menor que 21, "Jovem".*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL,"Portuguese");
	
	int idade;

	printf("\nInforme a sua idade: ");
	scanf("%d", &idade);

	if(idade>70){
		printf("\nVelho.");
	}else{
		if(idade>21){
			printf("\nAdulto.");
		}else{
			if(idade<=21){
				printf("\nJovem.");
			}
		}
	}

	return 0;
}
